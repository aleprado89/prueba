<?php
session_start();
//DATOS ALUMNO
$_SESSION['alu_nombre'] = "Nombre";
$_SESSION['alu_apellido'] = "Apellido";
$_SESSION['alu_dni'] = "Dni";
$_SESSION['alu_idAlumno'] = 2300;
$_SESSION['alu_idPersona'] = "";
//DATOS PLATAFORMA
$_SESSION['anioPlataformaAlu'] = 2024;  
$_SESSION['colegio'] ="Nombre Colegio";
$_SESSION['idCiclo'] = 10; 
//DATOS SELECCIONES FORMULARIOS 
$_SESSION['idP'] = 22;
$_SESSION['nombreP'] = "Nombre Plan";
$_SESSION['idM'] = "";
$_SESSION['nombreM'] = "";
$_SESSION['nombreC'] = "";
