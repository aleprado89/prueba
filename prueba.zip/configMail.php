<?php
define('MAIL_HOST', 'smtp.hostinger.com');
define('MAIL_PORT', 587);
define('MAIL_USER', 'sistemasescolares@sesystem.com.ar');
define('MAIL_PASSWORD', 'Srsr4065.pase');
define('MAIL_FROM', 'sistemasescolares@sesystem.com.ar');
define('MAIL_FROM_NAME', 'SistemasEscolares');
?>